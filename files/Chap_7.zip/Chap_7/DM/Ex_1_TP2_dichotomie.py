from random import randint

def lancer_jeu():
    print("=== Jeu du Nombre Mystère ===")
    print("1 - L'ordinateur devine ton nombre")
    print("2 - Tu devines le nombre de l'ordinateur")
    mode = input("Choisis un mode (1 ou 2) : ")

    if mode == "1":
        nombre = input("Pense à un nombre entre 0 et 100 : ")
        if nombre.isdigit() and 0 <= int(nombre) <= 100:
            mode_ordinateur(int(nombre))
        else:
            print("Erreur : entre un nombre entre 0 et 100.")
    elif mode == "2":
        mode_humain(randint(0, 100))
    else:
        print("Mode invalide. Relance le jeu.")

def mode_ordinateur(nombre_utilisateur):
    print("\nMode 1 : L'ordinateur devine")
    print("Réponds par True ou False (avec une majuscule)")

    min_val, max_val = 0, 100
    while min_val <= max_val:
        guess = (min_val + max_val) // 2
        print(f"Ton nombre est-il < {guess} ?")
        rep = input("-> ").strip()
        if rep == "True":
            max_val = guess - 1
        elif rep == "False":
            print(f"C'est {guess} ?")
            confirmation = input("-> ").strip()
            if confirmation == "True":
                print(f"Super ! Le nombre était bien {guess}.\n")
                return
            elif confirmation == "False":
                min_val = guess + 1
            else:
                print("Réponds par True ou False.")
        else:
            print("Réponds par True ou False.")
    print("Erreur dans les réponses. Fin du jeu.")

def mode_humain(nombre_secret):
    print("\nMode 2 : Tu dois deviner")
    print("Pose une question comme :x>50 ou x<33")
    print("Tape exactement x==nombre pour deviner.")

    while True:
        question = input("Ta question : ").strip()
        if not question:
            print("Tu dois poser une question.")
            continue
        try:
            if eval(question.replace("x", str(nombre_secret))):
                print("VRAI\n")
            else:
                print("FAUX\n")
            if question.replace(" ", "") == f"x=={nombre_secret}":
                print(f"Bravo ! Le nombre mystère était {nombre_secret}.\n")
                break
        except:
            print("Erreur : question invalide. Utilise x==n, x<n ou x>n.\n")

# Lancement du jeu
lancer_jeu()
