def racine1(a, x):
    if a < 0:
        return None
    if a == 0:
        return 0, 0

    inf = 0
    sup = max(1, a)
    while sup - inf >= x:
        m = (inf + sup) / 2
        if m ** 2 > a:
            sup = m
        else:
            inf = m
    return inf, sup

if "__main__"==__name__: print(racine1(2,1))

