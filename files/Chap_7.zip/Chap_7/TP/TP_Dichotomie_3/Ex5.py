from random import randint
from Ex1 import *
from Ex4 import *

for i in range(10):
    nombre = randint(1,100)
    intervale = racine1(nombre,0.0001)
    assert intervale[0]<racine2(nombre,1)<intervale[1]