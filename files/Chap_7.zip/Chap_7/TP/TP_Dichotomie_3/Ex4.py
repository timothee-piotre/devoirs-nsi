def racine2(a,x0=1):
    for i in range(10):
        x0=(x0+(a/x0))/2
    return x0

if "__main__"==__name__: print(racine2(2,1))