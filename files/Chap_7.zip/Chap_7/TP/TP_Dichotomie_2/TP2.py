def pos_insertion_tout(L:list[int],v:int):
    g=0
    d=len(L)-1
    while g<=d:
        m=(g+d)//2
        if L[m]==v: return m+L.count(v)
        elif L[m]<v: g=m+1
        else: d=m-1
    return m+int(v>L[m])

def pos_insertion(lst, k):
    valeur = lst[k]
    gauche = 0
    droite = k - 1

    while gauche <= droite:
        milieu = (gauche + droite) // 2
        if lst[milieu] < valeur:
            gauche = milieu + 1
        else:
            droite = milieu - 1

    return gauche

def tri_insertion(liste):
    for k in range(1, len(liste)):
        i = pos_insertion(liste, k)
        valeur = liste[k]
        for j in range(k, i, -1):
            liste[j] = liste[j - 1]
        liste[i] = valeur
    return liste

# Question 4: Oui, et on peut supposer un gain de performance parce que la complexité 
# de la recherche par dichotomie est logarithmique donc sur de nombreuses valeurs, on 
# aura un tri plus efficaces qu'avec la méthode classique qui est quadratique

if "__main__"==__name__:
    assert pos_insertion_tout([1,12,23,34,45,56,67,78,89,90],0)==0
    assert pos_insertion_tout([1,12,23,34,45,56,67,78,89,90],100)==10
    assert pos_insertion_tout([1,12,23,34,45,56,67,78,89,90],50)==5
    assert pos_insertion_tout([1,12,23,34,45,56,67,78,89,90],23)==3

    assert pos_insertion([1,12,23,34,0,67,78,789,90],4)==0
    assert pos_insertion([1,12,23,34,45,100,78,67,89,90],5)==5
    assert pos_insertion([1,50,23,34,45,56,67,78,89,90],1)==1
    assert pos_insertion([1,0,23,34,45,56,67,78,89,90],1)==0
    assert pos_insertion([1,12,23,34,45,56,67,78,89,23],9)==4