from random import randint

liste_random=[]
def liste_random(x):
    return [randint(0,100) for i in range(x)]

def tri_insert(L):
    n=len(L)
    for k in range(0,n):
        j=k
        while j>0 and L[j - 1] > L[j]:
            L[j-1], L[j] = L[j], L[j-1]
            j-=1
    return L

if __name__=="__main__":
    l = liste_random(10)
    print(l)
    tri_insert(l)
    print(l)