from timeit import default_timer as timer
from random import randint
from Ex_3_Tp_insertion import tri_insert

debut=timer()
tri_insert([randint(0,50)]*15)
fin=timer()
temps=fin-debut
print(f"Le temps d'exécution est de {temps} secondes.")
print("--------------------------------------------------------------------------")

for i in range(100,1001,100):
    debut2=timer()
    tri_insert([randint(0,50)]*i)
    fin2=timer()
    temps2=fin2-debut2
    print(f"Le temps d'exécution du {int(i/100)}e passage est de {temps2} secondes.")
    print("--------------------------------------------------------------------------")