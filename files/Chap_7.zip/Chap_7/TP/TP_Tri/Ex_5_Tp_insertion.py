from matplotlib import pyplot as plt
from timeit import default_timer as timer
from Ex_3_Tp_insertion import *

abscisse = []
ordonnee1 = []
for i in range(100,1100,100):
    abscisse.append(i)
    s1=0
    for k in range(500):
        L=[randint(0,1000) for k in range(i)]
        start = timer()
        tri_insert(L)
        end=timer()
        s1+=end-start
    ordonnee1.append(s1)

if __name__=="__main__":
    axes = plt.gca()
    plt.xlabel("Longueur de la liste")
    plt.ylabel("temps (en s) pour 500 tris")
    plt.scatter(abscisse,ordonnee1,color="blue")
    plt.show()