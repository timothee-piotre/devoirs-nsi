from matplotlib import pyplot as plt
from timeit import default_timer as timer
from random import randint

def random_liste(x):
    return [randint(0,100) for i in range(x)]

def tri_insertion_dec(L):
    n=len(L)
    for k in range(0,n):
        j=k
        while j>0 and L[j - 1] < L[j]:
            L[j-1], L[j] = L[j], L[j-1]
            j-=1
    return L

def tri_par_selection_dec(L):
    n=len(L)
    for k in range(n-1):
        for i in range(k+1,n):
            if L[k]<L[i]: 
                L[k],L[i] = L[i],L[k]

if __name__=="__main__":
    l = random_liste(15)
    print(l)
    tri_insertion_dec(l)
    print("insertion:",l)

    l = random_liste(15)
    print(l)
    tri_par_selection_dec(l)
    print("selection:",l)

abscisse = []
ordonnee1 = []
for i in range(100,1100,100):
    abscisse.append(i)
    s1=0
    for k in range(500):
        L=[randint(0,1000) for k in range(i)]
        start = timer()
        tri_insertion_dec(L)
        end=timer()
        s1+=end-start
    ordonnee1.append(s1)

axes = plt.gca()
plt.xlabel("Longueur de la liste")
plt.ylabel("temps (en s) pour 500 tris")
plt.scatter(abscisse,ordonnee1,color="blue")

abscisse = []
ordonnee1 = []
for i in range(100,1100,100):
    abscisse.append(i)
    s1=0
    for k in range(500):
        L=[randint(0,1000) for k in range(i)]
        start = timer()
        tri_insertion_dec(L)
        end=timer()
        s1+=end-start
    ordonnee1.append(s1)

plt.scatter(abscisse,ordonnee1,color="red")
plt.show()