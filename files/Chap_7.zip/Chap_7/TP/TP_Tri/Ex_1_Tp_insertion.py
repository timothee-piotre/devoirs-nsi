def est_trie(tab):
    if sorted(tab) == tab:
        return True
    else:
        return False

if __name__=="__main__":
    print(est_trie([0,1,2,3]))
    print(est_trie([4,1,2,3]))
    print(est_trie([]))
    print(est_trie([0]))