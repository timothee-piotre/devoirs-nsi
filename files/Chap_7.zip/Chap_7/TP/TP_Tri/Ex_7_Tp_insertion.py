import Ex_5_Tp_insertion
import Ex_6_Tp_insertion
from matplotlib import pyplot as plt

axes = plt.gca()
plt.xlabel("Longueur de la liste")
plt.ylabel("temps (en s) pour 500 tris")
plt.scatter(Ex_5_Tp_insertion.abscisse,Ex_5_Tp_insertion.ordonnee1,color="blue")
plt.scatter(Ex_6_Tp_insertion.abscisse,Ex_6_Tp_insertion.ordonnee1,color="red")
plt.show()