from timeit import default_timer as timer
from Ex_2_Tp_insertion import *

for i in range(100,1100,100):
    L=[randint(0,i) for k in range(i)]
    start = timer()
    tri_par_select(L)
    end=timer()
    print(f"{i}: {end-start}s")



from matplotlib import pyplot as plt

abscisse = []
ordonnee1 = []
for i in range(100,1100,100):
    abscisse.append(i)
    s1=0
    for k in range(500):
        L=[randint(0,1000) for k in range(i)]
        start = timer()
        tri_par_select(L)
        end=timer()
        s1+=end-start
    ordonnee1.append(s1)

if __name__=="__main__":
    axes = plt.gca()
    plt.xlabel("Longueur de la liste")
    plt.ylabel("temps (en s) pour 500 tris")
    plt.scatter(abscisse,ordonnee1,color="blue")
    plt.show()