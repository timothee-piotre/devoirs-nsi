from random import randint
from Ex_1_Tp_insertion import est_trie

def tri_par_select(L):
    n = len(L)
    for k in range(0,n-2):
        for i in range(k+1,n-1):
            if L[k] > L[i]:
                L[k], L[i] = L[i], L[k]
    return L

liste=[randint(0,50)]*15
print(est_trie(tri_par_select(liste)))