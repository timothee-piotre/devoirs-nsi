def verifie_trie(liste):
    for i in range(len(liste)):
        if liste ==sorted(liste):
            return True
        else:
            return False

l=[1,2,3,4,5,6,7,8,9,0]
l2=[1,2,3,4,5,6,7,8,9]
assert verifie_trie(l)==False
assert verifie_trie(l2)==True