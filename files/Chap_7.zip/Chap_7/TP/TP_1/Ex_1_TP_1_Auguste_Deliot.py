def recherche(x,liste):
    return x in liste

l=[1,2,3,4,5,6,7,8,9,0]

assert recherche(12,l)==False
assert recherche("rotatif",l)==False
assert recherche(2,l)==True