def moyenne_pondere(lst_notes,lst_coefs):
    """lst_notes et lst_coefs sont deux listes de nombreux.
    Renvoie la moyenne ponderee des notes (float)"""
    somme_pond=0
    somme_coefs=0
    #LA
    for i in range(len(lst_notes)):
        somme_pond = somme_pond + lst_notes[1] * lst_coefs[i]
        somme_coefs = somme_coefs +lst_coefs[i]
        #ICI
    return somme_pond / somme_coefs