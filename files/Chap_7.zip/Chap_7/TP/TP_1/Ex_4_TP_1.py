def frequence(txt,lettre):
    compt = 0
    for i in txt:
        if str(i) == lettre:
            compt+=1
    return compt
            
assert frequence("harcèlement","h")==1
assert frequence("respect","v")==0