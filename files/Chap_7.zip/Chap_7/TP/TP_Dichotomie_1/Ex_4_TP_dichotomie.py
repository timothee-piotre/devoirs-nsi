from timeit import default_timer as timer
from Ex_3_TP_dichotomie_Auguste_Deliot import dichotomie
from Ex_2_TP_dichotomie_Auguste_Deliot import temps
from matplotlib import pyplot as plt


abscisse = []
ordonnees=[]
for i in range(1000,10001,1000):
    abscisse.append(i)
    s=0
    liste=[j for j in range(i)]
    for i in range(10000):
        s+=temps(dichotomie, liste,-1)
    ordonnees.append(s)
    
axes=plt.gca()
plt.xlabel("Longueur de la liste")
plt.ylabel("Durée de 10000 par dichotomie")
plt.scatter(abscisse,ordonnees,color="orange")
plt.show()