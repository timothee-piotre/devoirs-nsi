def recherche(T,x):
    n=len(T)
    for i in range(0,n):
        if T[i]==x:
            return True
    return False

if __name__=="__main__":
    assert recherche([1,2,3,4,5,6],1)==True
    assert recherche([6,2,3,4,5,1],1)==True
    assert recherche([],1)==False
    assert recherche([1,2,3,4,5,6],8)==False