from timeit import default_timer as timer

def dichotomie(Liste,nb):
    gauche=0
    droite=len(Liste)-1
    while gauche<=droite:
        m=(gauche+droite)//2
        if Liste[m]==nb:
            return m
        elif Liste[m]<nb:
            gauche=m+1
        else:
            droite = m-1
    return -1

def temps(fonction,L,nb):
    st=timer()
    fonction(L,nb)
    ed=timer()
    t=ed-st
    return t



if __name__=="__main__":
    print(dichotomie([i for i in range(10)], 10))
    print(dichotomie([i for i in range(10)], 9))
    print(temps(dichotomie, [i for i in range(10)], 10))
    print(temps(dichotomie, [i for i in range(100)], 99))
    print(temps(dichotomie, [i for i in range(1000)], 999))
    print(temps(dichotomie, [i for i in range(10000)], 9999))