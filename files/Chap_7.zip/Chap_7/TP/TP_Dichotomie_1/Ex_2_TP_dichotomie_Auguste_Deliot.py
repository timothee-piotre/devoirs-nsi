from timeit import default_timer as timer
from random import randint
from Ex_1_TP_dichotomie_Auguste_Deliot import recherche

def temps(fonction,L,nb):
    st=timer()
    fonction(L,nb)
    ed=timer()
    t=ed-st
    return t

liste_random=[]
def liste_random(x):
    return [randint(0,100) for i in range(x)]

if __name__=="__main__":
    print(temps(recherche,[i for i in range(10)],9))
    print(temps(recherche,[i for i in range(100)],99))
    print(temps(recherche,[i for i in range(1000)],999))
    print(temps(recherche,[i for i in range(10000)],9999))