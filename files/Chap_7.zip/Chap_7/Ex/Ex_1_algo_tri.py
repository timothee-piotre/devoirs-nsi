from random import randint

def tri_insertion(L):
    n=len(L)
    for k in range(0,n):
        j=k
        insertion(L,k)
    return L

def insertion(L,i):
    while i>0 and L[i - 1] > L[i]:
        L[i-1], L[i] = L[i], L[i-1]
        i-=1
    return L

def liste_random(x):
    return [randint(0,100) for i in range(x)]

if __name__=="__main__":
    l = liste_random(15)
    print(l)
    print(tri_insertion(l))

