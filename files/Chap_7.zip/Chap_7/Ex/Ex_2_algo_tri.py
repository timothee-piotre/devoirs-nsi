from Ex_1_algo_tri import insertion
from random import randint

def tri_par_insertion_externe(L):
    liste=L.copy()
    n=len(liste)
    for k in range(0,n):
        insertion(liste,k)
    return L,liste

def liste_random(x):
    return [randint(0,100) for i in range(x)]

if __name__=="__main__":
    l = liste_random(15)
    print(l)
    print(tri_par_insertion_externe(l))