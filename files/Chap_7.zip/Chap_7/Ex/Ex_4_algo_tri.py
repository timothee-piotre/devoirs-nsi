from Ex_1_algo_tri import tri_insertion
from random import randint

def frequence(l):
    tri_insertion(l)
    c=1
    liste_freq=[]
    k=l[0]
    for i in range(1,len(l)):  
        if l[i]==k:
            c+=1
        else :
            liste_freq.append((c,k))
            k=l[i]
            c=1
    tri_insertion(liste_freq)
    liste_freq.reverse()
    return liste_freq[0]

if __name__=="__main__":
    assert frequence([1,1,1,23,5])==(3,1)
    assert frequence([52,56,1,1,1,1])==(4,1)
    assert frequence([1,1,1,2,2,5,2,5,2,1])==(4,2)
    assert frequence([1,1,1,2,2,5,2,5,1])==(4,1)