from Ex_1_algo_tri import tri_insertion
from random import randint

def plus_petit(l,k):
    tri_insertion(l)
    return l[:k]

def liste_random(x):
    return [randint(0,100) for i in range(x)]

if __name__=="__main__":
    l = liste_random(15)
    print(l)
    print(plus_petit(l,4))