def indice(liste,element):
    """Renvoie un indice i tel que liste[i]==elelment
    s'il y en a un, sinon renvoie None"""
    g=0
    d=len(liste)-1
    while g<=d:
        m=(g+d)//2
        if liste[m]==element:
            return m
        elif liste[m]>element:
            d=m-1
        else:
            g=m+1
    return
 
assert indice([1,3,5,17,17,19],3)==1
assert indice([1,3,5,17,17,19],4)==None
assert indice([1,3,5,17,17,19],17)==3 or indice([1,3,5,17,17,19],17)==4