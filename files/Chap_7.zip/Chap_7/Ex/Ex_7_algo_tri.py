from 
def tri_a_bulles(liste):
    n = len(liste)
    for i in range(n):
        for j in range(0, n - i - 1):
            if liste[j] > liste[j + 1]:
                liste[j], liste[j + 1] = liste[j + 1], liste[j]
    return liste


def tri_a_bulles_optimise(liste):
    n = len(liste)
    for i in range(n):
        echange = False
        for j in range(0, n - i - 1):
            if liste[j] > liste[j + 1]:
                liste[j], liste[j + 1] = liste[j + 1], liste[j]
                echange = True
        if not echange:
            break
    return liste

if __name__=="__main__":
    print("Tri par dénombrement :", tri_par_denombrement([2, 2, 9, 4, 3, 0, 3, 8, 0, 9, 1, 0, 4, 7, 1, 1, 10, 4, 10, 0], 10))
    print("Tri à bulles :", tri_a_bulles([64, 34, 25, 12, 22, 11, 90]))
    print("Tri à bulles optimisé :", tri_a_bulles_optimise([64, 34, 25, 12, 22, 11, 90]))
