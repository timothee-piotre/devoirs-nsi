def tri_par_denombrement(liste, maxv):
    E = [0] * (maxv + 1)
    for val in liste:
        E[val] += 1
    liste_triee = []
    for i in range(len(E)):
        for k in range(E[i]):
            liste_triee.append(i)
    return liste_triee


if __name__ == "__main__":
    print(tri_par_denombrement([2, 2, 9, 4, 3, 0, 3, 8, 0, 9, 1, 0, 4, 7, 1, 1, 10, 4, 10, 0], 10))
    print(tri_par_denombrement([2, 2, 9, 4, 3, 4, 20, 0], 20))
    print(tri_par_denombrement([2, 2, 8, 4, 3,3, 8, 0, 9, 15, 0, 4, 7, 1, 1, 10, 4, 10, 0], 15))