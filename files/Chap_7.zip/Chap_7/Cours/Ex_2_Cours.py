from random import randint

liste=[]
for i in range(30):
    liste.append(randint(0,100))

maxi=liste[0]
j=1
while j<len(liste):
    if maxi < liste[j]:
        maxi=liste[j]
    j+=1

print(liste)
print("le max est :",maxi)