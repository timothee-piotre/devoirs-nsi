# 1)
def tri_par_selection(tableau):
    for indice_actuel in range(len(tableau) - 1):
        for indice_suivant in range(indice_actuel + 1, len(tableau)):
            if tableau[indice_actuel] > tableau[indice_suivant]: 
                tableau[indice_actuel], tableau[indice_suivant] = tableau[indice_suivant], tableau[indice_actuel]
    return tableau
                
# Tests

assert tri_par_selection([23, 7, 18, 4, 39]) == [4, 7, 18, 23, 39]

assert tri_par_selection([10, 9, 8, 7, 6]) == [6, 7, 8, 9, 10]

assert tri_par_selection([3, 6, 9, 12, 15]) == [3, 6, 9, 12, 15]

assert tri_par_selection([42]) == [42]

assert tri_par_selection([]) == []

# 2)
def position_plus_petit(tab):
    minimum = tab[0]
    for idx in tab:
        if minimum > idx:
            minimum = idx
    return minimum

# Tests
assert position_plus_petit([23, 7, 18, 4, 39]) == 4
assert position_plus_petit([10, 9, 8, 7, 6]) == 6
assert position_plus_petit([3, 6, 9, 12, 15]) == 3
assert position_plus_petit([42]) == 42
