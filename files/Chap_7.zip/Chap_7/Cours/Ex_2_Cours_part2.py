def indice_minimum(l):
    indice=0
    val=l[0]
    for i in range(len(l)):
        if val>l[i]:
            val, indice = l[i], i
    return indice

# Tests

assert indice_minimum([34, 12, 25, 9, 47]) == 3
assert indice_minimum([5, 4, 3, 2, 1]) == 4
assert indice_minimum([1, 2, 3, 4, 5]) == 0
assert indice_minimum([5]) == 0