from random import randint

liste=[]
for i in range(30):
    liste.append(randint(0,100))

maxi=liste[0]
for j in range(1,len(liste)):
    if maxi < liste[j]:
        maxi=liste[j]

print(liste)
print("Le max est :",maxi)