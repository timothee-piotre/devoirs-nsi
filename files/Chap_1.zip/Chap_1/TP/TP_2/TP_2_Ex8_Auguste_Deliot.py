entier = int(input("saisir un entier : "))
for i in range(1,11) :
    print(entier * i)