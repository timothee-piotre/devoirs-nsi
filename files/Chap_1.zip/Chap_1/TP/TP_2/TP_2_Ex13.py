annees = int(input("saisir le nombre d\'annees : "))
solde = 5000
for i in range(1,annees+1) :
    solde = solde * 1.025
print(solde)