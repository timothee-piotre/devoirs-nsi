a = 0
alphab = "azertyuiopqsdfghjklmwxcvbn"
phrase = input("saisir une phrase : ")
for caractere in phrase :
    if caractere.lower() in alphab:
        a = a + 1
print(a)