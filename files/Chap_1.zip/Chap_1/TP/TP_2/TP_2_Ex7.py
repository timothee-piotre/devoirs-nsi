phrase = input("saisir une phrase : ")
consonnes = "zrtpqsdfghjklmwxcvbn"
newphrase = ""
for caractere in phrase :
    if caractere.lower() in consonnes:
        caractere = "*"
        newphrase = newphrase + caractere
    else :
        newphrase = newphrase + caractere
print(newphrase)

