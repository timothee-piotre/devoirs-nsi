chaine1 = input("Saisi un mot : ")
chaine2 = ""
for caractere in chaine1:
    chaine2 = caractere + chaine2
if chaine1 == chaine2:
    print(chaine1 + " est un palindrome")
else :
    print (chaine1 + " n\'est pas un palindrome")