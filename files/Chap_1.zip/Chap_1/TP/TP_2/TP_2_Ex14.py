etage = int(input("saisir le nombre d\'etage : "))
nborange = etage**2
print("le nombre d\'orange a cet etage est :",nborange) #(f"le nombre d\'orange a l\'etage {etage} est : {nborange}")