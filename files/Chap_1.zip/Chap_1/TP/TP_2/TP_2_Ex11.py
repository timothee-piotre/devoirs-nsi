S = int(input("saisir un entier : "))
for i in range(S,S+1001) :
    S=S+i
print(S)