#a = "*"
for i in range(1,8) :
    print("*" * i)