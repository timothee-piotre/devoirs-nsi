a = 3 #int(input("saisir un entier : "))
for i in range(a,a+13) :
    a=a*3
    print(a)