entier = 7
for i in range(1,101) :
    print(entier * i)