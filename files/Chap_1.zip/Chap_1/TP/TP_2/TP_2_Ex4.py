compteur = 0
mot = "abracadabra"
for caractere in mot :
    if caractere == "a":
        compteur = compteur + 1
print(compteur)