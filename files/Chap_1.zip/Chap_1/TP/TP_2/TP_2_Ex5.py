a = 0
phrase = input("saisir une phrase : ")
for caractere in phrase :
    if caractere == " ":
        a = a + 1
print(a)