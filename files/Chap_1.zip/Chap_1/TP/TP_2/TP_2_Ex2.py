chaine1 = "Bonjour"
chaine2 = ""
for caractere in chaine1:
    chaine2 = caractere + chaine2
print(chaine2)
 #cela permet de changer l'ordere des caracteres