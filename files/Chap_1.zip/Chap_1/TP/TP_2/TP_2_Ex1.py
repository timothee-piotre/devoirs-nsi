chaine = "Bonjour les NSI"
for caractere in chaine:
    print(caractere)
for caractere in chaine:
    print(caractere, end=" ")
    
print("a","b","c","d")
print("a","b","c","d",sep="-")
