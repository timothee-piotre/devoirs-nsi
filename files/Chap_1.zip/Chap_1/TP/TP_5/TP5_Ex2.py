from turtle import *
speed(0)

def carre(cote, couleur) :
    begin_fill()
    for i in range(4):
        color(couleur)
        ht()
        fd(cote)
        left(90)
    end_fill()

def cercledecarre() :
    for i in range(36):
        carre(10, "red")
        penup()
        forward(10 + 3)
        left(10)
        forward(3)
        pendown()

cercledecarre()