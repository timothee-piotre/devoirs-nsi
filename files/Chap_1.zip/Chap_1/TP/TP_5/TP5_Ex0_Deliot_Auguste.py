from turtle import *
speed(0)
for i in range(12):
    forward(150)
    left(150)
    ht()
#1 ce programme permet de dessiner une etoile
#2 speed permet de choisir la vitesse d'execussion
#3 ht supprimele cursseur