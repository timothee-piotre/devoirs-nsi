from turtle import *

def flocon1() :
    pendown()
    for i in range(6):
        fd(100)
        right(135)
        fd(15)
        bk(15)
        left(270)
        fd(15)
        bk(15)
        rt(135)
        bk(100)
        left(60)
    penup()
       
def flocon2() :
    pendown()
    for i in range(6):
        fd(100)
        right(45)
        fd(15)
        bk(15)
        left(90)
        fd(15)
        bk(15)
        right(45)
        bk(100)
        left(60)
    penup()
       
def flocon3():
    pendown()
    for i in range(6):
        fd(100)
        rt(45)
        fd(15)
        left(90)
        fd(15)
        left(90)
        fd(15)
        left(90)
        fd(15)
        left(135)
        bk(100)
        left(60)
    penup()

def flocons():
    flocon2()
    setx(-240)
    flocon1()
    setx(260)
    flocon3()

flocons()