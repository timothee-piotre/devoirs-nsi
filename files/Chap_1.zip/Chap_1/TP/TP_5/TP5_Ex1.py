from turtle import *

def carre(cote, couleur) :
    for i in range(4):
        color(couleur)
        ht()
        fd(cote)
        left(90)

carre(100, "red")
