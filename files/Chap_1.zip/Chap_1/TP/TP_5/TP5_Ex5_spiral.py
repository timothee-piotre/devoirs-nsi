from turtle import *

def spirale():
    ht()
    speed(0)
    pensize(8)
    r=4
    d=90
    for i in range(25):
        circle(r, d)
        r=r+4
        

spirale()