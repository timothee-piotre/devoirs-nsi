from turtle import *

def carre(cote) :
    for i in range(4):
        ht()
        fd(cote)
        left(-90)

def carreplus():
    ht()
    speed(0)
    begin_fill()
    color("grey")
    carre(250)
    end_fill()
    up()
    goto(125, 5)
    pensize(25)
    pencolor("white")
    lt(-90)
    fd(50)
    lt(-4)
    down()
    fd(150)
    bk(75)
    lt(94)
    fd(75)
    bk(150)



carreplus()