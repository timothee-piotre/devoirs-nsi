from turtle import *

def triangle(cote, couleur) :
    for i in range(3):
        color(couleur)
        ht()
        fd(cote)
        left(120)
triangle(100, "red")

def suitetriangle() :
    for i in range(10):
        triangle(100, "red")
        penup()
        forward(100)
        pendown()
        
suitetriangle()