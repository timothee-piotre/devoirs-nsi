from turtle import *
speed(0)
def carre(cote, couleur) :
    for i in range(4):
        color(couleur)
        ht()
        fd(cote)
        left(90)

def suitecarre() :
    for i in range(10):
        carre(10, "red")
        penup()
        forward(15)
        pendown()
        

suitecarre()