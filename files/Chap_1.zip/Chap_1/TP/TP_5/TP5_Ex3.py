from turtle import *
speed(0)

def triangle(cote, couleur) :
    begin_fill()
    for i in range(3):
        color(couleur)
        ht()
        fd(cote)
        left(120)
    end_fill()

def carre(cote, couleur) :
    begin_fill()
    for i in range(4):
        color(couleur)
        ht()
        fd(cote)
        right(90)
    end_fill()
    
def cercledecarreettriangle() :
    for i in range(18):
        carre(10, "red")
        penup()
        forward(10 + 3)
        left(10)
        forward(3)
        pendown()
        triangle(10, "blue")
        penup()
        forward(10 + 3)
        left(10)
        forward(3)
        pendown()
cercledecarreettriangle()