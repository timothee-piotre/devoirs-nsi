from turtle import *

def pointintero():
    ht()
    pensize(15)
    speed(0)
    lt(90)
    circle(-50, 240)
    circle(50, 60)
    fd(20)
    up()
    fd(30)
    down()
    circle(3)


pointintero()