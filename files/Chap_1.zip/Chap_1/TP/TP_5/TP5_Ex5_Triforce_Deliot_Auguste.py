from turtle import *

def triangle() :
    begin_fill()
    for i in range(3):
        fd(100)
        left(120)
    end_fill()
    
def triforce(cote, couleur):
    ht()
    triangle()
    up()
    setx(-100)
    down()
    triangle()
    right(120)
    bk(200)
    triangle()
    
triforce(100, "black")
