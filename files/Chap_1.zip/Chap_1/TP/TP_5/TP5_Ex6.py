from turtle import *

n=int(input("nombre de pétales : "))

def rosace():
    speed(0)
    ht()
    for i in range(n):
        setheading(360/n*i) 
        for r in range(2,17):
            fd(15)
            lt(r)
        for s in range(16,0,-1):
            fd(15)
            lt(s)
            
 
rosace()

