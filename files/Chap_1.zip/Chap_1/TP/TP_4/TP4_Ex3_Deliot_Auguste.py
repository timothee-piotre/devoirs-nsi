def compter_lettre(lettre,phrase):
    c=0
    for caractere in phrase:
        if caractere.lower()==lettre.lower():
            c=c+1
    return c
phrase=input("Saisir une phrase : ")
lettre=input("Lettre choisi : ")
print("La lettre",lettre,"est",compter_lettre(lettre,phrase),"fois dans","'",phrase,"'.")