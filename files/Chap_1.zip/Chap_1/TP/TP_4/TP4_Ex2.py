def vitesse(d,t):
    return d/t
d=float(input("Saisir la distance : "))
t=float(input("Saisir le temps : "))
print("La vitesse est de",vitesse(d,t),"km/h.")