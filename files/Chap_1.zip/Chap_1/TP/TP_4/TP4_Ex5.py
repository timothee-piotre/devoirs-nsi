def solde(p,r):
    s=p*(1-r/100)
    return s
p=int(input("Saisir le prix initial (en €) : "))
r=int(input("Saisir la remise (en %) : "))
print("L'article coutera",solde(p,r),"€")