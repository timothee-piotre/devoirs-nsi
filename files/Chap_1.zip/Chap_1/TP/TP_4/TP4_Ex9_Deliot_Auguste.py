def latin_cochon(chaine1):
    voyelles = "aeiouy"
    if chaine1[0].lower() in voyelles:
        return chaine1
    else:
        return chaine1[1:] + chaine1[0] + "um"

mot = input("Entrez une phrase : ")
print("'",mot,"'","en latin cochon est :",latin_cochon(mot))
