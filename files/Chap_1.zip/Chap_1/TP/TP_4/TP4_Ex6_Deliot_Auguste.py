def maximum(a,b):
    if a<b:
        pg=b
    else:
        pg=a
    return pg
def minimum(a,b):
    if a>b:
        pp=a
    else:
        pp=a
    return pp
a=int(input("Saisir un entier a : "))
b=int(input("Saisir un entier b : "))
if a!=b:
    print("Le plus grand est",maximum(a,b),",et le plus petit est",minimum(a,b),".")
else:
    print("a et b sont égaux")