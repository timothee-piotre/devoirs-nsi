def nb_armstrong(n):
    for i in range(0,n):
        if i[0]**3+i[1]**3+i[2]**3==i:
            print(i)
nombre = int(input("Entrez un entier positif: "))
print("Les nombre d'armstrong inferieur a",nombre,"sont :",nb_armstrong(nombre))

#pas les erreurs,désolé