def exercice1 (a): #un seul argument: a
    return a**2-a+1 #elle affiche le calcule avec l'argument comme nombre