def pair(n):
    if n%2==0:
        np="pair"
    else :
        np="impair"
    return np
n=int(input("Saisir un entier : "))
print(n,"est",pair(n),".")
