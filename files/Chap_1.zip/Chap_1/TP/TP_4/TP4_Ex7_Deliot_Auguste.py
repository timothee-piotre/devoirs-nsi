def diviseur(n):
    c=0
    for d in range(1,n+1):
        if n%d==0:
            c=c+1
    return c
n=int(input("Saisir un entier : "))
print(n,"a",diviseur(n),"diviseurs.")

"""13 a 2 diviseurs.
   15 a 4 diviseurs.
   36 a 9 diviseurs.

"""