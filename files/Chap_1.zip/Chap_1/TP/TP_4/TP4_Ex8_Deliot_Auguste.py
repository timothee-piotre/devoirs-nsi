def affiche_diviseur(n):
    for d in range(1, n + 1):
        if n % d == 0:
            print(d)

n = int(input("Saisir un entier positif : "))
print("Les diviseurs de", n, "sont :")
affiche_diviseur(n)