signal = input("Un probleme ? : ")
if signal.lower() == "danger" :
    print("Declancher l\'alerte !")
else :
    print("Tout va bien")