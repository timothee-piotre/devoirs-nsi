un_entier = int(input("Choisi un nombre : "))
if un_entier != 25:
        if un_entier > 25 :
                print("est superieur à 25")
        else :
                print("est inferieur à  25")
else :
                print("est egal à 25")
                