un_entier = int(input("saisir un entier : "))
if un_entier%2 == 0:
    print(un_entier , "est pair")
else :
    print(un_entier , "est impair")