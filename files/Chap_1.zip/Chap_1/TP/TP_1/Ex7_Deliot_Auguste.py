a = float(input("choisi un reel : "))
b = float(input("choisi un reel : "))
if a < b :
    print("les reels on ete choisi dans l\'ordre croissant")
elif a > b :
    print("les reels on ete choisi dans l\'ordre decroissant")
else :
    print("sont egaux")