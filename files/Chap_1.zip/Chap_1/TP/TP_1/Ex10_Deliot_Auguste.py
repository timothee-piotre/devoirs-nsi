a = float(input("choisi un reel a : "))
b = float(input("choisi un reel b : "))
if a == 0 :
        print("la reponse est : x =",-b)
elif a != 0 :
        print("la reponse est : x =",-b/a)
