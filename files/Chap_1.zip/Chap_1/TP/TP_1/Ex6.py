a = int(input("choisi un nombre : "))
if a > 0 :
    print("est +")
elif a < 0 :
    print("est -")
else :
    print("est nul")