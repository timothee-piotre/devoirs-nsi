mot = input("Choisi un mot : ")
lettre = input("Coisi une lettre : ")
print(lettre in mot)