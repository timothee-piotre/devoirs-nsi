un_entier = int(input("saisir un entier : "))
if un_entier%7 == 0:
    print(un_entier , "est divisible par 7")
    print("le quotient:" , un_entier//7)
else :
    print(un_entier , "n\'est divisible par 7")