i = 5
while i >= 0:
    i=i-1
    print (i, end=' ')
    #la boucle par de i et effectue l'instruction jusqu'a -1