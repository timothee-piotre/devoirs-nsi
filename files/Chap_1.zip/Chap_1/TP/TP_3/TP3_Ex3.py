n = 0
while 3**n < 10000:
    n = n+1
    print(n)