#for
for a in range(1,21):
    print("Avec for. Le carré de",a,"est :",a**2,"et sont cube est :",a**3,".")

print()

#while
n=1
while n<20:
    n=n+1
    print("Avec while. Le carré de",n,"est :",n**2,"et sont cube est :",n**3,".")