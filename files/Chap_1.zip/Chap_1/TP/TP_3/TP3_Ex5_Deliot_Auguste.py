n=1
while n<16384:
    n=n*2
    d=n*1.1183
    print(n,"€ = $",d)