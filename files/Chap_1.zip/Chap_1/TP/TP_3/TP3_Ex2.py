table = 7
for i in range(5,-2,-1):
    print(i-1,"x", table, "=", (i-1)*table)