def convert(t):
    """convertit une durée t (demandée à l'utilisateur en minutes) en heures et en minutes.
       t : int (temps en minutes)
       h : int (heures)
       m : int (minutes)
       retourne une str sous la forme '...h ...min'
    """
    h = t // 60
    m = t % 60
    print(f"{h} h {m} min")


temps = int(input("Temps en minutes : "))
convert(temps)


def FarToCel(f):
    """convertit une température de Fahrenheit en Celsius.
       f : float (température en °F)
       c : float (température en °C)
       retourne un float c arrondi aux centièmes
    """
    c = (f - 32) * 5 / 9
    return round(c, 2)

temp_f = float(input("Température en °F : "))
print("Température en °C :", FarToCel(temp_f))
