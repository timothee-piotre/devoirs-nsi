def convert(t):
    """convertit une durée t (demander à l'utilisateur) en minutes en heures et minutes.
       t : int (temps en minutes)
       h : int (heures)
       m : int (minutes)
       retourne une str sous la forme '...h ...min'
    """
    h = t // 60
    m = t % 60
    return f"{h} h {m} min"

def convert2(t):
    """convertit une durée t (demander à l'utilisateur) en minutes en heure décimale.
       t : int (temps en minutes)
       h_dec : float (heure decimal)
       retourne un float h_dec arrondi aux centièmes
    """
    h_dec = t / 60
    return round(h_dec, 2)



temps = int(input("Temps en minutes : "))

print("Heures et minutes :", convert(temps))
print(f"Heure décimale : {convert2(temps)} heures")
