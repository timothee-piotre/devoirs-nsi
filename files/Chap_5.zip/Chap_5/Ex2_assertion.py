def surface(l, L):
    """Une fonction qui renvoie la surface d'un rectangle
    L:int ou float longueur
    l:int ou float largeur
    Le retour sera float ou int"""
    if type(l) in (float, int) and type(L) in (float, int):
        if l>=0 and L>=0:
            return l*L

assert surface("a", 1) is None, "Erreur str"
assert surface(1, "b")  is None, "Erreur str"
assert surface(True, (2,))  is None, "Erreur bool"
assert surface(3, -1) is None
assert surface(-1, 3) is None
assert surface(3, 3)==9
assert surface(2, 1.5)==3
assert surface(3, 1.5)==4.5