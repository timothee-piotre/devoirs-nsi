#1]

def suivant(n):
    """Renvoie l'entier suivant n
    Renvoie un entier"""
    if type(n)==int: return n+1


assert suivant(0.45) is None, "Erreur float"
assert suivant("str") is None, "Erreur str"
assert suivant(True) is None, "Erreur bool"
assert suivant(7) == 8
assert suivant(0) ==1
assert suivant(-54) == -53

#2]

def suivant_bis(n):
    """Renvoie les deux entiers suivant n
    Renvoie une liste de deux entiers"""
    if type(n)==int: return [n+1, n+2]


assert suivant_bis(0.45) is None, "Erreur float"
assert suivant_bis("str") is None, "Erreur str"
assert suivant_bis(True) is None, "Erreur bool"
assert type(suivant_bis(68)) == list, "Erreur de type du renvoie"
assert suivant_bis(0) == [1, 2]
assert suivant_bis(-23) == [-22, -21]