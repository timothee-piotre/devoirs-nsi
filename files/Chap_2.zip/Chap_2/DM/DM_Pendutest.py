from turtle import *
from math import *

def dessiner_pendu(erreurs):
    speed(0)
    if erreurs == 1:
        fd(200)       # Socle
        bk(100)
    elif erreurs == 2:
        lt(90)
        fd(300)       # Poteau vertical
    elif erreurs == 3:
        bk(40)
        rt(45)
        fd(sqrt(3200))  # Barre transversale
    elif erreurs == 4:
        rt(45)
        bk(40)
        fd(100)       # Poutre
    elif erreurs == 5:
        rt(90)
        fd(20)        # Corde
    elif erreurs == 6:
        rt(90)
        circle(25)    # Tête
    elif erreurs == 7:
        circle(25, 180)
        rt(90)
        fd(90)        # Corps
    elif erreurs == 8:
        bk(65)
        rt(45)
        fd(45)        # Bras gauche
    elif erreurs == 9:
        bk(45)
        lt(90)
        fd(45)        # Bras droit
    elif erreurs == 10:
        bk(45)
        rt(45)
        fd(65)
        rt(45)
        fd(55)        # Jambe gauche
    elif erreurs == 11:
        bk(55)
        lt(90)
        fd(55)        # Jambe droite

lettres_jouees = []

def demander_lettre():
    lettre = input("Saisir une lettre : ").lower()
    while len(lettre) != 1:
        lettre = input("Saisir une seule lettre : ").lower()
    while lettre in lettres_jouees:
        lettre = input("Cette lettre a déjà été proposée. Saisir une autre lettre : ").lower()
    lettres_jouees.append(lettre)
    return lettre

def remplace(reference, actuel, lettre):
    if lettre in reference:
        nouveau_mot = ""
        for i in range(len(reference)):
            if reference[i] == lettre:
                nouveau_mot += lettre
            else:
                nouveau_mot += actuel[i]
        return nouveau_mot
    else:
        return None

def pendu(mot, nb_erreurs_max):
    mot_actuel = '-' * len(mot)
    erreurs = 0
    
    print("\nBienvenue dans le jeu du Pendu !")
    print("Le mot à deviner contient " + str(len(mot)) + " lettres.\n")
    
    while erreurs < nb_erreurs_max and mot_actuel != mot:
        print("\nMot à deviner : " + mot_actuel)
        if lettres_jouees:
            print("Lettres déjà jouées : " + (", ".join(lettres_jouees)))
        else:
            print("Aucune")
        print("Erreurs restantes : " + str(nb_erreurs_max - erreurs))
        
        lettre = demander_lettre()
        
        mot_mis_a_jour = remplace(mot, mot_actuel, lettre)
        
        if mot_mis_a_jour:
            mot_actuel = mot_mis_a_jour
            print("\nBonne nouvelle ! La lettre '" + lettre + "' est dans le mot.")
        else:
            erreurs += 1
            print("\nDommage, la lettre '" + lettre + "' n'est pas dans le mot.")
            dessiner_pendu(erreurs)
        
        print("\n------------------------------")
    
    if mot_actuel == mot:
        print("\nFélicitations ! Vous avez trouvé le mot : " + mot + " 🎉")
    else:
        print("\nVous avez perdu. Le mot était : " + mot + " 😔")


def demarrer():
    mot = input("Saisir le mot à faire deviner : ").lower()
    nb_erreurs_max = 11
    pendu(mot, nb_erreurs_max)

demarrer()
