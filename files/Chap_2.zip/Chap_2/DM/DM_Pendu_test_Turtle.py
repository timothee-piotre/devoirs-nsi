from turtle import *
from math import *

def dessiner_pendu(erreurs):
    speed(0)
    if erreurs == 1:
        fd(200)
        bk(100)
    elif erreurs == 2:
        lt(90)
        fd(300)
    elif erreurs == 3:
        bk(40)
        rt(45)
        fd(sqrt(3200))
    elif erreurs == 4:
        rt(45)
        bk(40)
        fd(100)
    elif erreurs == 5:
        rt(90)
        fd(20)
    elif erreurs == 6:
        rt(90)
        circle(25)
    elif erreurs == 7:
        circle(25, 180)
        rt(90)
        fd(90)
    elif erreurs == 8:
        bk(65)
        rt(45)
        fd(45)
    elif erreurs == 9:
        bk(45)
        lt(90)
        fd(45)
    elif erreurs == 10:
        bk(45)
        rt(45)
        fd(65)
        rt(45)
        fd(55)
    elif erreurs == 11:
        bk(55)
        lt(90)
        fd(55)
