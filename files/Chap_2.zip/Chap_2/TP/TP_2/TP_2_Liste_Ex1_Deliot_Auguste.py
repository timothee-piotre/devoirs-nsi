def tri(liste):
    Lpos=[]
    Lneg=[]
    for i in liste:
        if i<0:
            Lneg.append(i)
        else:
            Lpos.append(i)
    print(Lneg + Lpos)

L=[1,-2,3,-4,5,-6,7,-8,9,-10]

tri(L)