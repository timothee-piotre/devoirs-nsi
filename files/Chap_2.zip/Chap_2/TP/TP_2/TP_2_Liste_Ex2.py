def double(liste):
    Laff=[] 
    for i in liste:
        if i not in Laff:
            Laff.append(i)
    print(Laff)
    
L=[1,2,5,8,6,2,5,9,1,8,8]

double(L)