def moyenne(valeurs, coefficients):

    numerateur = 0
    denominateur = 0
    
    for i in range(len(valeurs)):
        numerateur += valeurs[i] * coefficients[i]
        denominateur += coefficients[i]
    
    return numerateur / denominateur

Val = [12.5, 13.6, 18.4, 9.7]
Coeff = [2, 3, 5, 4]
print(moyenne(Val, Coeff))
