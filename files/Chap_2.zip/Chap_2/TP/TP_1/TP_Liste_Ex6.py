from random import *

n=int(input("saisir le nombre de valeurs de la liste : "))
liste_n=[]
listepair=[]
listeimpair=[]
for i in range(n):
    liste_n.append(randint(0,100))

for c in liste_n:
    if c%2==0:
        listepair.append(c)
    else:
        listeimpair.append(c)
print(liste_n)
print("les pair de lise_n", listepair)
print("les impair de lise_n",listeimpair)