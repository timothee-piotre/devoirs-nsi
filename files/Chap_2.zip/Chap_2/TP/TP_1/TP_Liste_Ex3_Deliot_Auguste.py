ma_liste=['lapin','chat','chien','chiot','dragon','ornithorynque']
print(ma_liste)
ma_liste.reverse()
print(ma_liste)
ma_liste.append('troll')
print(ma_liste)
listedom=['lapin','chat','chien','chiot','cochon d inde','phasme','Roger']
for i in listedom:
        if i in ma_liste :
             ma_liste.remove(i)  
print(ma_liste)