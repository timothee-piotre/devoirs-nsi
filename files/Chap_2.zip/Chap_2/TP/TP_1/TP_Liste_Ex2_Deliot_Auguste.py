liste1=['janvier','fevrier','mars','avril','mai','juin,','juillet','aout','septembr','octobre','novembre','decembre']
liste2=[31,28,31,30,31,3,31,31,30,31,30,31]
liste3=[]
for i in range(12):
    liste3.append(liste1[i])
    liste3.append(liste2[i])
print(liste3)