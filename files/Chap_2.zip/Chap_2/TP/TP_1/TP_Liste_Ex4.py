liste1=['lapin','chat','chien','chiot','dragon','ornithorynque']
l=0
for mot in liste1:
    for caractere in mot:
        l=l+1
    print(mot, "a", l, "lettres")
    l=0