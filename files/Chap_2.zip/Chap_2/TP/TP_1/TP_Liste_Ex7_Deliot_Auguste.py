from math import *
n=int(input("saisir un entier superieur ou égal à 1 : "))
liste=[]
for i in range(n):
    v=int(input("saisir une valeur pour la liste : "))
    liste.append(v)
print(liste)
print(max(liste))
print(min(liste))
s=liste[0]
for c in liste[1:]:
    s=s+c
print(s)
moyenne= sum(liste)/len(liste)
print(moyenne)
k=int(input("saisir un entier : "))
if k in liste:
    print(k, "est dans la liste")
else:
    print(k, "n'est pas dans la liste")