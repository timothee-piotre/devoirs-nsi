from random import *

n=int(input("saisir le nombre de valeurs de la liste : "))
listen=[]
for i in range(n):
    listen.append(randint(0,100))
maxi=listen[0]
for c in listen:
    if c>maxi:
        maxi=c
print(listen)
print(maxi)
