n=int(input("saisir un entier positif : "))
liste=[]
for i in range(1,n+1):
    liste.append(i**3)
print(liste)
