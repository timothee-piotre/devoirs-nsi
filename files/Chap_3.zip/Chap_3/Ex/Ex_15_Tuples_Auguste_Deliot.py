def min_max_moy(liste):
    minimum = min(liste)
    maximum = max(liste)
    moyenne = sum(liste) / len(liste)
    return (minimum, maximum, moyenne)

valeurs = input("Entrez une liste de valeurs séparées par des espaces : ")
valeurs = [int(i) for i in valeurs.split(" ")]
resultat = min_max_moy(valeurs)
print(resultat)
