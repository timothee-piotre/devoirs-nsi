epicerie = [("tomates", 20), ("pommes", 10), ("carottes", 5), ("poires", 3), ("bananes", 4), ("ananas", 1)]

tri = int(input("Tri alphanumérique (1) ou tri alphabétique (2) ? "))

if tri == 1:
    epicerie_inverse = [(quantite, fruit) for fruit, quantite in epicerie]
    epicerie_inverse.sort()
    resultat = [(fruit, quantite) for quantite, fruit in epicerie_inverse]
    
else:
    def tri_par_nom(nom):
        return nom[0]
    resultat = sorted(epicerie, key=tri_par_nom)

print(resultat)