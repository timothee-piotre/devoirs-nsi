def decodage(saisie, base):
    base = base.lower()
    liste_code = saisie.split(" ")

    if base == "2" or base == "binaire":
        resultat = [chr(int(caractere, 2)) for caractere in liste_code]
        return "".join(resultat)

    if base == "10" or base == "décimal":
        resultat = [chr(int(caractere)) for caractere in liste_code]
        return "".join(resultat)

    if base == "16" or base == "hexadecimal":
        resultat = [chr(int(caractere, 16)) for caractere in liste_code]
        return "".join(resultat)

    else:
        return "Cet encodage est indisponible (essayez en base 2, 10 ou 16)."


code = input("Saisir le code à décoder : ")
base_2 = input("Base de l'encodage du code (2, 10 ou 16): ")

print(decodage(code, base_2))


