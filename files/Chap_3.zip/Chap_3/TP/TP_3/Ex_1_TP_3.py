def encodage(saisie, base):
    base = base.lower()
    
    if base == "2" or base == "binaire":
        resultat = [str(bin(ord(caractere)))[2:] + " " for caractere in saisie]
        return "".join(resultat)
    
    if base == "10" or base == "décimal":
        resultat = [str(ord(caractere)) + " " for caractere in saisie]
        return "".join(resultat)
    
    if base == "16" or base == "hexadecimal":
        resultat = [str(hex(ord(caractere)))[2:] + " " for caractere in saisie]
        return "".join(resultat)
    
    return "Cet encodage est indisponible (essayez en base 2, 10 ou 16)."

texte = input("Saisir le texte à encoder : ")
base = input("Base de l'encodage (2, 10 ou 16) : ")

print("Votre texte encodé en base", base, "est :", encodage(texte,base))
