def f1(lettre):
    return lettre, ord(lettre),bin(ord(lettre))

def f2(nombre):
    return chr(nombre),nombre, bin(nombre)


for i in range(97,123):
     print(f2(i))