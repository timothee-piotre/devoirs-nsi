def f1(lettre):
    return lettre, ord(lettre),bin(ord(lettre))


print(f1("é"))
print(f1("è"))
print(f1("ê"))
print(f1("â"))
print(f1("ï"))
print(f1("ç"))
print(f1("ù"))
print(f1("É"))
print(f1("È"))
print(f1("Ê"))
print(f1("Â"))
print(f1("Ï"))
print(f1("Ç"))
print(f1("Ù"))


def afficher_lettres(min_code, max_code):
    min_code=int(input("code min : "))
    max_code=int(input("code max : "))
    for code in range(min_code, max_code + 1):
        print(chr(code))