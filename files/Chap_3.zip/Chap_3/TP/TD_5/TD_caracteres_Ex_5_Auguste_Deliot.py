def f(lettre):
    a = lettre.encode('utf8')
    b = a.decode('latin_1')
    return b

print(f("a"))
print(f("é"))
