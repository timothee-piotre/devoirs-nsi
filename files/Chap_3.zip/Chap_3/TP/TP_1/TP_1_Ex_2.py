alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def deconversion(nb,b):
    resultat= 0
    
    for i in range(len(nb)):
        resultat += alphabet.index(nb[i])*b**(len(nb)-i-1)
        
        
    return resultat

print(deconversion("1001",2))
print(deconversion("1011",2))
print(deconversion("1010",2))
print(deconversion("10101010",2))
print(deconversion("55",6))
print(deconversion("344",8))
print(deconversion("7F",16))