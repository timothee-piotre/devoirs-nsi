alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def deconversion2(nb,b):
    resultat= 0
    for i in range(len(nb)):
        resultat = resultat*b + alphabet.index(nb[i])
    return resultat

print(deconversion2("1001",2))
print(deconversion2("1011",2))
print(deconversion2("1010",2))
print(deconversion2("10101010",2))
print(deconversion2("55",6))
print(deconversion2("344",8))
print(deconversion2("7F",16))