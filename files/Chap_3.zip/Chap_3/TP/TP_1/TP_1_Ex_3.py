alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def conversion2(nb,b):
    resultat=""
    k=1
    while b**k <= nb :
        k+=1
    for i in range(k-1,-1,-1):
        resultat = alphabet[nb%b] + resultat
        nb = nb//b
            
    return resultat

print(conversion2(1,2))
print(conversion2(10,2))
print(conversion2(255,2))
print(conversion2(255,4))
print(conversion2(255,6))
print(conversion2(255,8))
print(conversion2(255,16))
print(conversion2(0,2))