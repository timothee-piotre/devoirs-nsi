alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def conversion(nb,b):
    resultat=""
    k=1
    while b**k <= nb :
        k+=1
    for i in range(k-1,-1, -1):
        if nb >= b**i:
            resultat += alphabet[nb//b**i]
            nb = nb%b**i
        else:
            resultat += "0"
            
    return resultat

print(conversion(1,2))
print(conversion(10,2))
print(conversion(255,2))
print(conversion(255,4))
print(conversion(255,6))
print(conversion(255,8))
print(conversion(255,16))
print(conversion(0,2))