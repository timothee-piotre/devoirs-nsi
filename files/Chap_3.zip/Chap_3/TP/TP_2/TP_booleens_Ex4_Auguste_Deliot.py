from algebre_boole import*

def xor(a,b):
    return et(ou(a,b), nand(a,b))