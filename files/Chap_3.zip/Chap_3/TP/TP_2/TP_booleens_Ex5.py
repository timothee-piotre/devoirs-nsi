from algebre_boole import*

# a ou (a et b)
print(table2(lambda a,b : ou(a,et(a,b))))

# a et (a ou b)
print(table2(lambda a,b : et(a,ou(a,b))))

# a ou ((non a) et b)
print(table2(lambda a,b : ou(a,et(non(a),b))))

# (a ou b) et ((non a) ou b)
print(table2(lambda a,b : et(ou(a,b),ou(non(a),b))))

# (a xor b) ou (a et b)
print(table2(lambda a,b : ou(xor(a,b),et(a,b))))

# (a xor b) et (a ou(non b))
print(table2(lambda a,b : et(xor(a,b),ou(a,non(b)))))