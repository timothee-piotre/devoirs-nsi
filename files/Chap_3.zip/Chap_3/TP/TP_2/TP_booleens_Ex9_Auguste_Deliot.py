from algebre_boole import *

def et(a,b):
    if a:
        if b:
            return 1
    return 0

print("et")
table2(et)

def ou(a,b):
    if a:
        return 1
    if b:
        return 1
    return 0

print("ou")
table2(ou)

def non(a):
    if a:
        return 0
    return 1

def xor(a,b):
    if a:
        if b:
            return 0
        return 1
    if b:
        return 1
    return 0

print("xor")
table2(xor)

def impl(a,b):
    if b:
        return 1
    if a:
        return 0
    return 1

print("=> implication (impl)")
table2(impl)