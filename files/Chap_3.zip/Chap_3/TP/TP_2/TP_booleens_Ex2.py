print(x==y or 3==3) # erreur car x et y ne sont pas defini

print(3==3 or x==y) # true car seulement l'un des deux doit être vrai et la premiere operation est defini

print(1==2 and x==y) # false car les deux operations doivent être verifiées et la premiere est fausse