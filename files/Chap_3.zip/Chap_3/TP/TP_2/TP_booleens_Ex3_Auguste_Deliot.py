from algebre_boole import*

def ou(a,b):
    return nand(non(a), non(b))