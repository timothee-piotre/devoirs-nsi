from algebre_boole import*

def impl(a,b):
    return ou(non(a),b)