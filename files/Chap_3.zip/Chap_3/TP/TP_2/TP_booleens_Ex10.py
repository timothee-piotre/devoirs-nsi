from algebre_boole import *

def et2(a,b):
    if max(a,b):
        if min(a,b):
            return 1
    return 0

print("table et")
table2(et2)

def ou2(a,b):
    if max(a,b):
        return  1
    if min(a,b):
        return  1
    return 0

print("table ou")
table2(ou2)