from algebre_boole import *

def tauto2(f):
    for a in range(2):
        for b in range(2):
            if not f(a,b): return 0
    return 1

def tauto3(f):
    for a in range(2):
        for b in range(2):
            for c in range(2):
                if not f(a,b,c): return 0 
    return 1
