a = 4
b = 54
c = 2

print(a<b<c)

a = 25
b = 87
c = 100

print(a<b<c)
