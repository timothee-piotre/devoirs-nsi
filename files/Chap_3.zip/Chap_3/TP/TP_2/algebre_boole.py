def nand(a,b):
    if a==0:
        return 1
    if b==0:
        return 1
    return 0

def table2(f):
    print("a","b","f(a,b)")
    for a in range(2):
        for b in range(2):
            print(a,b,f(a,b))
            
def table3(f):
    print("a","b","c","f(a,b)")
    for a in range(2):
        for b in range(2):
            for c in range(2):
                print(a,b,c,f(a,b,c))
            
def non(a):
    return nand(a,a)

def et(a,b):
    return non(nand(a,b))

def ou(a,b):
    return nand(non(a), non(b))

def xor(a,b):
    return et(ou(a,b), nand(a,b))

def expression(a,b):
    return et(ou(a,b),ou(non(a),b))

def impl(a,b):
    return ou(non(a),b)



