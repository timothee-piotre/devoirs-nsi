from algebre_boole import *

print("a =>(b=>a)")
print(table2(lambda a,b : impl(a,impl(b,a))))

print("a => (b => c)) => ((a => b) => (a=>c)")
print(table3(lambda a,b,c : impl(impl(a,impl(b,c)),impl(impl(a,b),impl(a,c)))))

print("((non b) => (non a)) => (a => b)")
print(table2(lambda a,b : impl(impl(non(b),non(a)),impl(a,b))))

print("a => (b => (a et b))")
print(table2(lambda a,b, :impl(a,impl(b,et(a,b)))))

print("(a et b) => a")
print(table2(lambda a,b: impl(et(a,b), a)))

print("(a et b) => b")
print(table2(lambda a,b: impl(et(a,b),b)))

print("a => (a ou b)")
print(table2(lambda a,b: impl(a, ou(a,b))))

print("b => (a ou b)")
print(table2(lambda a,b: impl(b, ou(a,b))))

print("(a ou b) => ((a => c) => ((b => c) => c))")
print(table3(lambda a,b,c: impl(ou(a,b),impl(impl(a,c),impl(impl(b,c),c)))))