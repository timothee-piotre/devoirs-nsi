from algebre_boole import*

def table3(f):
    print("a","b","c","f(a,b)")
    for a in range(2):
        for b in range(2):
            for c in range(2):
                print(a,b,c,f(a,b,c))
    
    
    
