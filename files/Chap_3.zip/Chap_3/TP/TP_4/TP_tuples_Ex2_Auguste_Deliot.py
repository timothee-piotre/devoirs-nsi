def triplet_pythagoricien(n):
    l=[]
    triplets=[]
    for i in range(n+1):
        l.append(i**2)
    for c in range(1,n+1):
        for a in range(1,c):
            b_carre=c**2-a**2
            if b_carre in l:
                b=int(b_carre**0.5)
                if a<b<c:
                    triplets.append((a,b,c))
    return triplets
