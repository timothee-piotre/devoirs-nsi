def dist_carre(A,B):
    AB=((B[0]-A[0])**2)-((B[1]-A[1])**2)
    return AB

def millieu(A,B):
    M=((B[0]-A[0])/2)-((B[1]-A[1])/2)
    return M