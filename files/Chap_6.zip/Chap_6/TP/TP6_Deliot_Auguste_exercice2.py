import csv

with open("Prenoms2008.csv", encoding="utf-8") as fichier:
    table_prenoms2008 = list(csv.DictReader(fichier))

with open("Prenoms2009.csv", encoding="utf-8") as fichier:
    table_prenoms2009 = list(csv.DictReader(fichier))

#fusion tables
reunion_prenoms_08_09 = table_prenoms2008 + table_prenoms2009

with open("reunion_prenoms2008_2009.csv", "w", newline="", encoding="utf-8") as f:
    out = csv.DictWriter(f, reunion_prenoms_08_09[0].keys())
    out.writeheader()
    out.writerows(reunion_prenoms_08_09)

#trier par nombre
def sort_by_number(l):
    if l["prenom"] == "_PRENOMS_RARES":
        return 0
    return int(l["nombre"])

#top 10 prénoms 2008
print("\nTop 10 des Prénoms les plus fréquents en 2008")
table_prenoms2008.sort(key=sort_by_number, reverse=True)
for i, x in enumerate(table_prenoms2008[:10]):
    print(f"Prénom 2008 n°{i+1} : {x['prenom']} - Occurrence = {x['nombre']}")

#top 10 prénoms 2009
print("\nTop 10 des Prénoms les plus fréquents en 2009")
table_prenoms2009.sort(key=sort_by_number, reverse=True)
for i, x in enumerate(table_prenoms2009[:10]):
    print(f"Prénom 2009 n°{i+1} : {x['prenom']} - Occurrence = {x['nombre']}")

#jointure deux fichiers
jointure_prenoms_2008_2009 = []
for i, p9 in enumerate(table_prenoms2009):
    for p8 in table_prenoms2008:
        if p9["prenom"] == p8["prenom"] and p9["sexe"] == p8["sexe"]:
            jointure_prenoms_2008_2009.append({
                "sexe": p9["sexe"],
                "prenom": p9["prenom"],
                "annee": "2008-2009",
                "nombre": int(p9["nombre"]) + int(p8["nombre"])
            })

#fichier jointure
with open("jointure_prenoms2008_2009.csv", "w", newline="", encoding="utf-8") as f:
    out = csv.DictWriter(f, jointure_prenoms_2008_2009[0].keys())
    out.writeheader()
    out.writerows(jointure_prenoms_2008_2009)

#top 10 m(sexe = 1)
prenoms0809_hommes = [i for i in jointure_prenoms_2008_2009 if i["sexe"] == "1"]
prenoms0809_hommes.sort(key=sort_by_number, reverse=True)
print("\nTop 10 des prénoms masculins les plus fréquents (2008-2009)")
for i, x in enumerate(prenoms0809_hommes[:10]):
    print(f"Prénom 2008-2009 masculin n°{i+1} : {x['prenom']} - Occurrence = {x['nombre']}")

#top 10 f(sexe = 2)
prenoms0809_femmes = [i for i in jointure_prenoms_2008_2009 if i["sexe"] == "2"]
prenoms0809_femmes.sort(key=sort_by_number, reverse=True)
print("\nTop 10 des prénoms féminins les plus fréquents (2008-2009)")
for i, x in enumerate(prenoms0809_femmes[:10]):
    print(f"Prénom 2008-2009 féminin n°{i+1} : {x['prenom']} - Occurrence = {x['nombre']}")
