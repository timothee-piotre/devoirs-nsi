import csv

with open("Table_Membres.csv", encoding="utf-8") as fichier:
    table_Membres = list(csv.DictReader(fichier, delimiter=","))
with open("Table_Prets.csv", encoding="utf-8") as fichier:
    table_Prets = list(csv.DictReader(fichier, delimiter=","))
with open("Table_Livre.csv", encoding="utf-8") as fichier:
    table_Livre = list(csv.DictReader(fichier, delimiter=","))

#jointure 1

def jointure_mp(TableA,TableB):
    return{"prenom":TableA["prenom"],"idm":TableB["idm"],"idl":TableB["idl"]}

joint_membre_prets=[]
for LigneA in table_Membres:
    for LigneB in table_Prets:
        if LigneA["idm"] == LigneB["idm"]:
            joint_membre_prets.append(jointure_mp(LigneA,LigneB))
        
with open("jointure_membre-prets.csv","w",encoding="utf8",newline="") as sortie:
    table_membre_prets=csv.DictWriter(sortie,['prenom','idm','idl'])
    table_membre_prets.writeheader()
    table_membre_prets.writerows(joint_membre_prets)

#jointure 2
    
def jointure_lp(TableA,TableB):
    return {"idl":TableA["idl"],"idm":TableA["idm"],"titre":TableB["titre"]}

joint_prets_livre=[]
for LigneC in table_Prets:
    for LigneD in table_Livre:
        if LigneC["idl"] == LigneD["idl"]:
            joint_prets_livre.append(jointure_lp(LigneC,LigneD))
            
with open("jointure_livre-prets.csv","w",encoding="utf8",newline="") as sortie:
    table_livre_prets=csv.DictWriter(sortie,['idm','idl','titre'])
    table_livre_prets.writeheader()
    table_livre_prets.writerows(joint_prets_livre)
    
#4]
    #1)
    
def jointure_mlp(TableA,TableB):
    return {"prenom":TableA["prenom"],"idm":TableA["idm"],"idl":TableB["idl"],"titre":TableB["titre"]}

joint_membre_prets_livre=[]
for LigneE in joint_membre_prets:
    for LigneF in table_Livre:
        if LigneE["idl"] == LigneF["idl"]:
            joint_membre_prets_livre.append(jointure_mlp(LigneE,LigneF))
print(joint_membre_prets_livre)

with open("jointure_membre_livre_pret_1.csv","w",encoding="utf-8",newline="") as sortie:
    table_membre_livre_prets=csv.DictWriter(sortie,["prenom",'idm','idl','titre'])
    table_membre_livre_prets.writeheader()
    table_membre_livre_prets.writerows(joint_membre_prets_livre)

    #2)
    
compr_membre_pret_livre = [
    {r: e for r, e in list(m.items()) + list(p.items()) + list(l.items())}
    for m in table_Membres
    for p in table_Prets
    for l in table_Livre
    if m["idm"] == p["idm"] and l["idl"] == p["idl"]
]

with open("jointure_membre_livre_pret_2.csv","w",encoding="utf-8",newline="") as sortie:
    table_membre_livre_prets=csv.DictWriter(sortie,["prenom",'idm','idl','titre'])
    table_membre_livre_prets.writeheader()
    table_membre_livre_prets.writerows(compr_membre_pret_livre)