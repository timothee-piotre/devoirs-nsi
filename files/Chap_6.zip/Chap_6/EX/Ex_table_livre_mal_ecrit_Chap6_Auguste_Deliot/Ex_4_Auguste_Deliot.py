import csv

id_t=input("Donner les livres avec l\'identifiant de l'emprunter et l\'année : ")

with open("Abonne.csv") as fichier:
    abo = list(csv.DictReader(fichier))
    
with open("Emprunt.csv") as fichier:
    emprunt = list(csv.DictReader(fichier))
    
with open("Livre.csv") as fichier:
    livre = list(csv.DictReader(fichier))

join=[]

for nb_livre in range(len(livre)):
    for nb_emprunt in range(len(emprunt)):
        for nb_abo in range(len(abo)):
            if livre[nb_livre]["IDL"] == 