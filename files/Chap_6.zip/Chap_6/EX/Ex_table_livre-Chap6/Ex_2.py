import csv

LIVRE = [{'IDL': '179',
          'Titre': 'Kyoto',
          'Auteur': 'Kawabata'
          }]

print(LIVRE)

LIVRE.append({'IDL': '158',
              'Titre': 'L\'art d\'avoir toujours raison',
              'Auteur': 'Schopenhauer'})

LIVRE.append({'IDL': '248',
              'Titre': 'Ma Boheme',
              'Auteur': 'Rimbaud'})

LIVRE.append({'IDL': '237',
              'Titre': 'The Shining',
              'Auteur': 'Stephen King'})

LIVRE.append({'IDL': '132',
              'Titre': 'Théorie des ensembles',
              'Auteur': 'Georg Cantor'})

with open("Livre.csv", "w", encoding="utf-8", newline="") as fichier:
    out = csv.DictWriter(fichier,LIVRE[0].keys())
    out.writeheader()
    out.writerows(LIVRE)

print()
print("Livres")
print(LIVRE)





emp = [{'IDL': '158',
          'IDA': '27',
          'ANNEE':2024}]

emp.append({'IDL': '237',
              'IDA': '27',
              'ANNEE':2020})

emp.append({'IDL': '132',
              'IDA': '27',
              'ANNEE':2022})

with open("Emprunt.csv", "w", encoding="utf-8", newline="") as fichier:
    table_emprunt = csv.DictWriter(fichier,emp[0].keys())
    table_emprunt.writeheader()
    table_emprunt.writerows(emp)

print()
print("Emprunt")
print(emp)





abo = [{'IDA': '48',
          'Nom': 'Rita',
          'Age': 16,
          'NBE':10}]

abo.append({'IDA': '33',
              'Nom': 'BBN.',
              'Age': 16,
              'NBE':10})

abo.append({'IDA': '65',
              'Nom': 'Riton',
              'Age': 19,
              'NBE':10})

with open("Abonne.csv", "w", encoding="utf-8", newline="") as fichier:
    table_abo = csv.DictWriter(fichier,abo[0].keys())
    table_abo.writeheader()
    table_abo.writerows(abo)

print()
print("Abonne")
print(abo)