import csv

#1]
with open("Livre.csv", encoding="utf-8") as fichier:
    livres = list(csv.DictReader(fichier))

with open("Emprunt.csv", encoding="utf-8") as fichier:
    emprunts = list(csv.DictReader(fichier))

with open("Abonne.csv", encoding="utf-8") as fichier:
    abonnes = list(csv.DictReader(fichier))

#2]
livres_kawabata = [livre for livre in livres if livre["Auteur"] == "Kawabata"]
print("Livres écrits par Kawabata :")
for livre in livres_kawabata:
    print(livre)

#3]
print("\nTitres des livres empruntes avec ID abonne et annee :\n")
for emp in emprunts:
    for l in livres:
        if emp["IDL"] == l["IDL"]:
            print(f"Titre : {l['Titre']} - ID abonné : {emp['IDA']} - Année : {emp['ANNEE']}")

#4]
def tri_par_auteur(livre):
    return livre["Auteur"]

livres_tries = sorted(livres, key=tri_par_auteur)

print("\ncouples (Auteur, Titre) tries par auteur :\n")
for livre in livres_tries:
    print(f"({livre['Auteur']} : {livre['Titre']})")