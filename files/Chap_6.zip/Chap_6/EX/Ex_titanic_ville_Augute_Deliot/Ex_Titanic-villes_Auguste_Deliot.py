import csv

#1]

#1)

with open("titanic.csv", encoding="utf-8") as fichier:
    titanic = list(csv.DictReader(fichier))
    
    
pass_first_class=[]
print("Passager de premiere classe :")
for p in titanic:
    if p["Pclass"] == "1":
        pass_first_class.append(p["Name"])
print(pass_first_class)

#2)

print(f"\n{len(pass_first_class)} passagers sont en 1ere classe.")

#2]

#1)
with open("villes.csv", encoding="utf-8") as fichier:
    villes = list(csv.DictReader(fichier))
    
nb_ville_10=[]
print("nb villes avec une augmentation de 10% :")
for h in villes:
    if int(h["nb_hab_1999"])*(1+10/100) <= int(h["nb_hab_2010"]):
        nb_ville_10.append(h["nom"])
print(nb_ville_10)

#2)

print(f"\n{len(nb_ville_10)} communes on augmenté de 10% d'habitans entre 1999 et 2010.")