import csv

fichier=open("NotesEleves.csv", encoding='utf8')
table=list(csv.DictReader(fichier,delimiter=","))

def maths_tri(ligne):
    return float(ligne["Maths"])

def NSI_tri(ligne):
    return float(ligne["NSI"])

def Anglais_tri(ligne):
    return float(ligne["Anglais"])


Maths_trie=sorted(table,key=maths_tri)
print(Maths_trie)

NSI_trie=sorted(table,key=NSI_tri)
print(NSI_trie)

Anglais_trie=sorted(table,key=NSI_tri)
print(Anglais_trie)