import csv

fichier1=open("NotesEleves.csv",encoding='utf8')
table1=list(csv.DictReader(fichier1,delimiter=','))
fichier1.close()

fichier4=open("NotesEleves4.csv",encoding='utf8')
table4=list(csv.DictReader(fichier4,delimiter=','))
fichier4.close()

def fusion(TableA,TableB):
    """
        In : TableA de la table1 et TableB de la table4
        Out : le dictionnaire fusion
    """
    return{"Nom":TableA["Nom"],"Prénom":TableB["Prénom"],"Année":TableB["Année"],"e-mail":TableB["e-mail"],"Maths":TableA["Maths"],"NSI":TableA["NSI"],"Anglais":TableA["Anglais"]}

jointure=[]
for LigneA in table1:
    for LigneB in table4:
        if LigneA["Nom"]==LigneB["Nom"]:
            jointure.append(fusion(LigneA,LigneB))

with open("jointure1-4.csv","w",encoding="utf8",newline="") as sortie:
    objet=csv.DictWriter(sortie,['Nom','Prénom','Année','e-mail','Maths','NSI','Anglais'])
    objet.writeheader()
    objet.writerows(jointure)