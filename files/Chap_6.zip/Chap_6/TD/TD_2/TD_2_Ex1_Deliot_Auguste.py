import csv

fichier=open("NotesEleves.csv", encoding='utf8')
table=list(csv.DictReader(fichier,delimiter=","))

#1]

t3=[ligne["Nom"] for ligne in table if float(ligne["Maths"]) > 18 and float(ligne["NSI"]) > 13]

print(t3)

#2]

t4=[ligne["Nom"] for ligne in table if float(ligne["Anglais"]) > 10 or float(ligne["Maths"]) > 18]

print(t4)