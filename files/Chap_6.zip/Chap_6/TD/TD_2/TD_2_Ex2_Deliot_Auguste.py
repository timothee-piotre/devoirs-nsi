import csv

fichier=open("NotesEleves.csv", encoding='utf8')
table=list(csv.DictReader(fichier,delimiter=","))

#1]

t23=[{"Nom":ligne["Nom"],"Maths+1":float(ligne["Maths"])+1} for ligne in table if float(ligne["Maths"]) != 20]

print(t23)

#2]

t24=[{"Nom":ligne["Nom"],"Moyenne": round((float(ligne["Maths"])+float(ligne["NSI"])+float(ligne["Anglais"]))/3,2)} for ligne in table]

print(t24)