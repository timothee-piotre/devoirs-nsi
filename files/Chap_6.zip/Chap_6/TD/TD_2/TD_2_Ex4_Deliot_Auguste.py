import csv

fichier1=open("NotesEleves.csv", encoding='utf8')
table1=list(csv.DictReader(fichier1,delimiter=","))
fichier1.close()

fichier2=open("NotesEleves2.csv", encoding='utf8')
table2=list(csv.DictReader(fichier2,delimiter=","))
fichier2.close()

table3=table1+table2

with open("NotesEleves3.csv","w",encoding="utf8",newline="") as sortie:
    objet=csv.DictWriter(sortie,['Nom','Maths','NSI','Anglais'])
    objet.writeheader()
    objet.writerows(table3)