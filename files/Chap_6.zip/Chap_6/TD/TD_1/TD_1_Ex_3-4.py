import csv

fichier=open("NotesEleves.csv", encoding='utf8')

table=list(csv.DictReader(fichier,delimiter=","))

fichier.close()

print(table)

print(table[1]['Nom'])

#Ex_4]

#2]
print(table[2]['Nom'],table[1]['NSI'])
#3]
print(table[0]['Nom'],table[0]['Maths'])