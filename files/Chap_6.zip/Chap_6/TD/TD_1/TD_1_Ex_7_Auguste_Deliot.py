import csv

def stats_csv(fichier):
    with open(fichier) as sortie:
        f=list(csv.reader(sortie,delimiter=","))
    return f"{len(f)} lignes et {len(f[0])} colonnes"
nf=input("Nom du fichier : ")
print(stats_csv(nf))