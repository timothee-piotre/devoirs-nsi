import csv
fichier=open("NotesEleves.csv", encoding='utf8')
table=list(csv.DictReader(fichier,delimiter=","))
fichier.close()


def convert(dico):
    nsi=float(dico['NSI'])
    math=float(dico['Maths'])
    anglais=float(dico['Anglais'])
    return {'Nom':dico['Nom'],'Maths':dico['Maths'],'NSI':dico['NSI'],'Anglais':dico['Anglais']}

table_valide=[convert(ligne) for ligne in table]

print(table_valide)