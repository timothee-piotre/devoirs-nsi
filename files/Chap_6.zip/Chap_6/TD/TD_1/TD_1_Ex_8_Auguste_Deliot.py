import csv

with open("NotesEleves.csv", encoding='utf8') as fichier:
    table = list(csv.DictReader(fichier, delimiter=","))

for ligne in table:
    ligne['Moyenne'] = round((float(ligne['Maths']) + float(ligne['NSI']) + float(ligne['Anglais'])) / 3, 2)

nb_eleves = len(table)
moyenne_maths = round(sum(float(ligne['Maths']) for ligne in table) / nb_eleves, 2)
moyenne_nsi = round(sum(float(ligne['NSI']) for ligne in table) / nb_eleves, 2)
moyenne_anglais = round(sum(float(ligne['Anglais']) for ligne in table) / nb_eleves, 2)
moyenne_globale = round(sum(float(ligne['Moyenne']) for ligne in table) / nb_eleves, 2)

moyenne_par_matiere = {'Nom': 'Moyenne Classe', 'Maths': moyenne_maths, 'NSI': moyenne_nsi, 'Anglais': moyenne_anglais, 'Moyenne': moyenne_globale}

with open("NouveauFichier.csv", "w", encoding="utf8", newline="") as sortie:
    objet = csv.DictWriter(sortie, table[0].keys())

    objet.writeheader()
    objet.writerows(table)
    objet.writerow(moyenne_par_matiere)