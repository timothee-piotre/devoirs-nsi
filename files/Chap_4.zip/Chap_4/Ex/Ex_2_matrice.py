#1

def matrice_nulle(n):
    return [[0 for _ in range(n)] for _ in range(n)]

#2

def matrice_identite(n):
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

n = int(input("Entrez la taille de la matrice : "))




mat_nulle = matrice_nulle(n)
mat_identite = matrice_identite(n)

print("\nMatrice nulle de taille", n, ":\n", mat_nulle)
print("\nMatrice identité I", n, ":\n", mat_identite)