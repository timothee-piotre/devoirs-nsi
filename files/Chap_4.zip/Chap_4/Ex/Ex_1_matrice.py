#1

A=[[-3,1,0],[1,-1,2],[0,-3,5]]

#2

def valabs(matrice):
    return [[abs(x) for x in ligne] for ligne in matrice]

valabs(A)

#3
b = valabs(A)

print(b)

#4
def somme(matrice):
    return sum(sum(ligne) for ligne in matrice)

print(somme(A))
