from random import randint

#1
def crea_matrice(n, a, b):
    return [[randint(a, b) for _ in range(n)] for _ in range(n)]

#2

M1 = crea_matrice(4, -10, 10)
M2 = crea_matrice(4, -10, 10)

#3

def somme_matrice(A, B):
    return [[A[i][j] + B[i][j] for j in range(len(A[0]))] for i in range(len(A))]




M3 = somme_matrice(M1, M2)

print("Matrice M1 :")
for ligne in M1:
    print(ligne)

print("\nMatrice M2 :")
for ligne in M2:
    print(ligne)

print("\nMatrice M3 (somme de M1 et M2) :")
for ligne in M3:
    print(ligne)
