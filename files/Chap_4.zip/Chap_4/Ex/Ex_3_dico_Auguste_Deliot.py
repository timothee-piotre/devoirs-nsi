# 1)
dico = {
    "bonjour": "hello",
    "oui": "yes",
    "non": "no",
    "aujourd'hui": "today",
    "merci": "thank you"
}

# 2a)
dico["chat"] = "cat"

# 2b)
def ajoute(mot1, mot2):
    if mot1 not in dico:
        dico[mot1] = mot2
    else:
        return "ce mot est deja dans le dictionnaire"


ajoute("chien", "dog")
print(ajoute("chat", "cat"))

# 3)
def affiche_mots_anglais():
    for mot in dico.values():
        print(mot)
        
affiche_mots_anglais()

# 4)
def supprime(car):
    for mot in list(dico.keys()):
        if mot[0] == car:
            del dico[mot]


supprime("b")

print(dico)