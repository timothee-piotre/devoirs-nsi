Website=["A","B","C","D","E","F"]

#3]

Hypertext = {}

Hypertext["A"]=["B","C","E"]
Hypertext["B"]=["F"]
Hypertext["C"]=["A","E"]
Hypertext["D"]=["B","C"]
Hypertext["E"]=["A","B","C","D"]
Hypertext["F"]=["E"]

#4]

Walk_number={}

Walk_number["A"] = 0
Walk_number["B"] = 0
Walk_number["C"] = 0
Walk_number["D"] = 0
Walk_number["E"] = 0
Walk_number["F"] = 0

#5]

import random
i=0
while i<=1000:
    x=random.choice(Website)
    while random.random()<=0.85:
        Walk_number[x]+=1
        x=random.choice(Hypertext[x])
        i+=1
print(Walk_number)

sites_classe = []
walk_items = list(Walk_number.items())

while walk_items:
    max_item = walk_items[0]
    for item in walk_items:
        if item[1] > max_item[1]:
            max_item = item
    sites_classe.append(max_item)
    walk_items.remove(max_item)


for i in range(len(sites_classe)):
    print("Site", sites_classe[i][0], ":", sites_classe[i][1], "visites")