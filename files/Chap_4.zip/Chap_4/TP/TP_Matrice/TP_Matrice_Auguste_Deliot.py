#1
"""
4+9+2=15
3+5+7=15
8+1+6=15
4+3+8=15
9+5+1=15
2+7+6=15
4+5+6=15
2+5+8=15
"""
#2
    #A]

M=[[4,9,2],
   [3,5,7],
   [8,1,6]]
   

def estCarre(M):
    for i in M:
        if len(i) != len(M):
            return False
    return  True

print(estCarre(M))

    #B]

def sommeLignes(M,i):
    s=0
    for v in M[i]:
        s+=v
    return s

print(sommeLignes(M,0))

    #C]

def sommeColonnes(M,i):
    s=0
    for n in M:
        s+=n[i]
    return s

print(sommeColonnes(M,2))

    #D]

def sommeDiagPrincipale(M):
    s=0
    for i in range(len(M)):
        s+=M[i][i]
    return s

print(sommeDiagPrincipale(M))

    #E]

def sommeDiagSecondaire(M):
    s=0
    n=1
    for j in range(len(M)):
        s+=M[j][j-n]
        n+=2
    return s

print(sommeDiagSecondaire(M))

    #F]

def estmagique(M):
    if not estCarre(M):
        return "La matrice n'est pas magique"

    for i in range(len(M)):
        if sommeLignes(M, i) != sommeLignes(M, 0) or sommeColonnes(M, i) != sommeLignes(M, 0):
            return "La matrice n'est pas magique"

    if sommeDiagPrincipale(M) != sommeLignes(M, 0) or sommeDiagSecondaire(M) != sommeLignes(M, 0):
        return "La matrice n'est pas magique"

    return "La matrice est une matrice magique"

print(estmagique(M))
